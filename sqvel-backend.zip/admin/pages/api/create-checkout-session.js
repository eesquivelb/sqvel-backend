import Stripe from "stripe";
import { adminDb } from "../../lib/firebaseAdmin";
import { getAuth } from "firebase-admin/auth";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).end();

  try {
    const { pieceId, idToken } = req.body;
    if (!pieceId || !idToken) {
      return res.status(400).json({ error: "pieceId and idToken are required" });
    }

    // Verify the customer is who they say they are
    const decoded = await getAuth().verifyIdToken(idToken);
    const customerUid = decoded.uid;
    const customerEmail = decoded.email;

    // Confirm the piece is real and still available — never trust price/availability from the client
    const pieceRef = adminDb.collection("pieces").doc(pieceId);
    const pieceSnap = await pieceRef.get();
    if (!pieceSnap.exists) return res.status(404).json({ error: "Piece not found" });

    const piece = pieceSnap.data();
    if (piece.status !== "available") {
      return res.status(409).json({ error: "This piece is no longer available" });
    }

    const session = await stripe.checkout.sessions.create({
      mode: "payment",
      payment_method_types: ["card"],
      customer_email: customerEmail,
      line_items: [
        {
          price_data: {
            currency: "usd",
            unit_amount: piece.priceCents,
            product_data: {
              name: `SQVEL — Edition ${piece.number}/${piece.editionSize}`,
              description: `Identity code ${piece.identityCode}`,
            },
          },
          quantity: 1,
        },
      ],
      metadata: {
        pieceId,
        customerUid,
      },
      success_url: `${process.env.NEXT_PUBLIC_SITE_URL}/account?purchase=success`,
      cancel_url: `${process.env.NEXT_PUBLIC_SITE_URL}/checkout/${pieceId}?canceled=1`,
    });

    // Soft-hold the piece for 15 minutes so two people can't buy it at once
    await pieceRef.update({
      status: "held",
      heldBy: customerUid,
      heldAt: Date.now(),
    });

    res.status(200).json({ url: session.url });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Could not start checkout" });
  }
}
