import Stripe from "stripe";
import { adminDb } from "../../../lib/firebaseAdmin";
import { buffer } from "micro";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);

export const config = { api: { bodyParser: false } }; // Stripe needs the raw body to verify the signature

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).end();

  const sig = req.headers["stripe-signature"];
  const rawBody = await buffer(req);

  let event;
  try {
    event = stripe.webhooks.constructEvent(rawBody, sig, process.env.STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    console.error("Webhook signature verification failed:", err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  if (event.type === "checkout.session.completed") {
    const session = event.data.object;
    const { pieceId, customerUid } = session.metadata;

    const pieceRef = adminDb.collection("pieces").doc(pieceId);

    await adminDb.runTransaction(async (tx) => {
      const pieceSnap = await tx.get(pieceRef);
      if (!pieceSnap.exists) throw new Error("Piece missing at fulfillment time");

      // Create the order record — this is the source of truth for "who owns what"
      const orderRef = adminDb.collection("orders").doc();
      tx.set(orderRef, {
        customerUid,
        pieceId,
        amountCents: session.amount_total,
        currency: session.currency,
        stripeSessionId: session.id,
        stripePaymentIntent: session.payment_intent,
        status: "paid",
        createdAt: Date.now(),
      });

      tx.update(pieceRef, {
        status: "sold",
        ownerUid: customerUid,
        soldAt: Date.now(),
        heldBy: null,
      });
    });
  }

  // If a checkout session expires unpaid, release the hold so the piece goes back on sale
  if (event.type === "checkout.session.expired") {
    const session = event.data.object;
    const { pieceId } = session.metadata;
    await adminDb.collection("pieces").doc(pieceId).update({
      status: "available",
      heldBy: null,
    });
  }

  res.status(200).json({ received: true });
}
