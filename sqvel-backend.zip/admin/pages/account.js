import { useEffect, useState } from "react";
import { collection, query, where, getDocs, orderBy } from "firebase/firestore";
import { signOut } from "firebase/auth";
import { auth, db } from "../lib/firebase";
import AuthGuard from "../components/AuthGuard";

function AccountInner() {
  const [pieces, setPieces] = useState([]);
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const user = auth.currentUser;

  useEffect(() => {
    async function load() {
      if (!user) return;
      const piecesQ = query(collection(db, "pieces"), where("ownerUid", "==", user.uid));
      const ordersQ = query(
        collection(db, "orders"),
        where("customerUid", "==", user.uid),
        orderBy("createdAt", "desc")
      );
      const [piecesSnap, ordersSnap] = await Promise.all([getDocs(piecesQ), getDocs(ordersQ)]);
      setPieces(piecesSnap.docs.map((d) => ({ id: d.id, ...d.data() })));
      setOrders(ordersSnap.docs.map((d) => ({ id: d.id, ...d.data() })));
      setLoading(false);
    }
    load();
  }, [user]);

  return (
    <div className="main">
      <div className="toolbar">
        <h1 className="page-title">Your account</h1>
        <button className="btn" onClick={() => signOut(auth)}>Sign out</button>
      </div>

      <h3 style={{ marginBottom: 16 }}>Your pieces</h3>
      {loading ? (
        <div className="empty-state">Loading…</div>
      ) : pieces.length === 0 ? (
        <div className="empty-state">You don't own a SQVEL piece yet.</div>
      ) : (
        <table style={{ marginBottom: 48 }}>
          <thead>
            <tr>
              <th>Edition</th>
              <th>Identity code</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {pieces.map((p) => (
              <tr key={p.id}>
                <td>{p.number}/{p.editionSize}</td>
                <td className="mono">{p.identityCode}</td>
                <td><span className="badge sold">owned</span></td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      <h3 style={{ marginBottom: 16 }}>Order history</h3>
      {orders.length === 0 ? (
        <div className="empty-state">No orders yet.</div>
      ) : (
        <table>
          <thead>
            <tr>
              <th>Date</th>
              <th>Amount</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {orders.map((o) => (
              <tr key={o.id}>
                <td>{new Date(o.createdAt).toLocaleDateString()}</td>
                <td>${(o.amountCents / 100).toFixed(2)}</td>
                <td><span className="badge sold">{o.status}</span></td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

export default function Account() {
  return (
    <AuthGuard>
      <AccountInner />
    </AuthGuard>
  );
}
