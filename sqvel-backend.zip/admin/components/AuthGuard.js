import { useEffect, useState } from "react";
import { useRouter } from "next/router";
import { onAuthStateChanged } from "firebase/auth";
import { auth } from "../lib/firebase";

export default function AuthGuard({ children }) {
  const [checked, setChecked] = useState(false);
  const [user, setUser] = useState(null);
  const router = useRouter();

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (u) => {
      setUser(u);
      setChecked(true);
      if (!u) router.replace("/login");
    });
    return () => unsub();
  }, [router]);

  if (!checked) return <div className="loading-screen">Loading…</div>;
  if (!user) return null;

  return children;
}
