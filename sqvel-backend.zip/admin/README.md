# SQVEL backend — payments + customer accounts

This is a real, working backend — not a mockup. It's built and ready to deploy; it just needs your live accounts and keys plugged in, since I can't create those for you from here.

## How the pieces fit together

| Job | Tool | Why |
|---|---|---|
| Your business email (`you@sqvel.com`), Docs, Drive, Calendar | **Google Workspace** | Runs the company day-to-day. Does not host an app or a database. |
| Customer accounts, sign-in, the database (orders, pieces, customers) | **Firebase** (a Google product, separate signup from Workspace) | This is the actual app infrastructure. |
| Charging cards, payouts to your bank | **Stripe** | Neither Google product processes payments. |
| Hosting this code so it's live | **Vercel** (easiest for Next.js) or **Firebase Hosting** | Where the code actually runs. |

You'll end up with three accounts: Google Workspace, a Firebase project (free to create, same Google login), and Stripe.

## What's actually built

- **Customer accounts** — signup (`/signup`), login (`/login`), and an account page (`/account`) showing a customer's owned pieces and order history. Firebase Auth handles passwords, verification, and password resets — you never touch or store a password yourself.
- **Payments** — `/api/create-checkout-session` starts a real Stripe Checkout session for a specific numbered piece; it re-checks the piece is actually available server-side (never trusts the browser), and puts a 15-minute hold on it so two people can't buy the same piece at once.
- **Order fulfillment** — `/api/webhooks/stripe` is the only place an order is ever marked paid. Stripe calls this directly after a successful charge; it writes the order, marks the piece sold, and links it to the customer — all in one atomic transaction, so you can't end up with a paid order and no piece assigned, or vice versa.
- **Security rules** (`firestore.rules`) — customers can only ever read their own orders and profile, never anyone else's. Nothing money- or ownership-related can be written directly from a browser — only your server (via the webhook) can do that, so a customer can't edit their own order to mark it "paid."

## What's not built yet (on purpose, given where you are)

- The shop/checkout UI on the public site (the button that actually calls `create-checkout-session`) — say the word and I'll wire that into `sqvel.html` next.
- Creating drops and generating the 250 identity codes each month — right now that'd be done directly in the Firebase console; an admin screen for this is a fast follow-up once the payment path is proven.
- Email receipts/confirmations — Stripe can send its own receipt automatically (toggle in Stripe settings) as a zero-code starting point.

## Go-live steps

1. **Firebase**: [console.firebase.google.com](https://console.firebase.google.com) → Add project → name it `sqvel` → enable **Authentication** (Email/Password provider) and **Firestore Database** (start in production mode). In Project Settings → General, add a web app to get your `NEXT_PUBLIC_FIREBASE_*` keys. In Project Settings → Service accounts → Generate new private key, for the `FIREBASE_ADMIN_*` keys.
2. **Stripe**: [dashboard.stripe.com](https://dashboard.stripe.com) → Developers → API keys for `STRIPE_SECRET_KEY`. Developers → Webhooks → Add endpoint → point it at `https://sqvel.com/api/webhooks/stripe`, select the `checkout.session.completed` and `checkout.session.expired` events, and copy the signing secret into `STRIPE_WEBHOOK_SECRET`.
3. Copy `.env.local.example` to `.env.local` and fill in everything from steps 1–2.
4. `firebase deploy --only firestore:rules` (needs the [Firebase CLI](https://firebase.google.com/docs/cli)) to publish `firestore.rules`.
5. `npm install`, then `npm run dev` to test locally.
6. Deploy to [Vercel](https://vercel.com) (connect the repo, paste in the same env vars) — this gives you a live URL and HTTPS automatically, which Stripe requires for the webhook.
7. Point `sqvel.com` at Vercel once you've bought the domain.

Steps 1, 2, and 6 need to happen in your accounts — I can walk you through any of them in more detail, but I can't click the buttons myself.
